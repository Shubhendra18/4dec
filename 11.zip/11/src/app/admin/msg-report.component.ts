import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-msg-report',
  templateUrl: './msg-report.component.html',
  styles: []
})
export class MsgReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
