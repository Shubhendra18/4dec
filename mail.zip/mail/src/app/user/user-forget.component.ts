import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-forget',
  templateUrl: './user-forget.component.html',
  styles: []
})
export class UserForgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
