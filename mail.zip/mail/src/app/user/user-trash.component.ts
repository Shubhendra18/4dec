import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-trash',
  templateUrl: './user-trash.component.html',
  styles: []
})
export class UserTrashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
