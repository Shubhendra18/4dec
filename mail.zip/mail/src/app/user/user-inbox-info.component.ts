import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-inbox-info',
  templateUrl: './user-inbox-info.component.html',
  styles: []
})
export class UserInboxInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
