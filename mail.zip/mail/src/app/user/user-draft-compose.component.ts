import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-draft-compose',
  templateUrl: './user-draft-compose.component.html',
  styles: []
})
export class UserDraftComposeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
