import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { DataTablesModule } from 'angular-datatables';
import { AvatarModule } from 'ngx-avatar';
const avatarColors = ["rgb(224, 40, 67)", "#212e77", "#237177", "#e79105", "#5d9208"];
import {NgxPaginationModule} from 'ngx-pagination';


import { UserNavbarComponent } from './user/user-navbar.component';
import { UserSidebarComponent } from './user/user-sidebar.component';
import { UserInboxComponent } from './user/user-inbox.component';
import { UserFooterComponent } from './user/user-footer.component';
import { UserComposeComponent } from './user/user-compose.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { HttpClientModule } from '@angular/common/http';
import { UserLoginComponent } from './user/user-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { MailboxserviceService } from './mailboxservice.service';
import { AdminDashboardComponent } from './admin/admin-dashboard.component';
import { ManageGroupComponent } from './admin/manage-group.component';
import { ManageUserComponent } from './admin/manage-user.component';
import { UserlistComponent } from './admin/user-list.component';
import { ResetPassComponent } from './admin/reset-pass.component';
import { BroadcastComponent } from './admin/broadcast.component';
import { SendReceivestatsComponent } from './admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './admin/usernotusingmboard.component';
import { LastloginComponent } from './admin/lastlogin.component';
import { MsgReportComponent } from './admin/msg-report.component';
import { AdminprofileComponent } from './admin/admin-profile.component';
import { AdminSidebarComponent } from './admin/admin-sidebar.component';
import { AdminNavbarComponent } from './admin/admin-navbar.component';
import { AdminFooterComponent } from './admin/admin-footer.component';
import { UserInboxInfoComponent } from './user/user-inbox-info.component';
import { UserSendComponent } from './user/user-send.component';
import { UserImportantComponent } from './user/user-important.component';
import { UserDraftComponent } from './user/user-draft.component';
import { UserDraftComposeComponent } from './user/user-draft-compose.component';
import { UserArchiveComponent } from './user/user-archive.component';
import { UserTrashComponent } from './user/user-trash.component';
import { UserForgetComponent } from './user/user-forget.component';
import { UserResetComponent } from './user/user-reset.component';
@NgModule({
  declarations: [
    AppComponent,
    UserNavbarComponent,
    UserSidebarComponent,
    UserInboxComponent,
    UserFooterComponent,
    UserComposeComponent,
    UserLoginComponent,
    AdminLoginComponent,
    AdminDashboardComponent,
    ManageGroupComponent,
    ManageUserComponent,
    UserlistComponent,
    ResetPassComponent,
    BroadcastComponent,
    SendReceivestatsComponent,
    UsernotusingmboardComponent,
    LastloginComponent,
    MsgReportComponent,
    AdminprofileComponent,
    AdminSidebarComponent,
    AdminNavbarComponent,
    AdminFooterComponent,
    UserInboxInfoComponent,
    UserSendComponent,
    UserImportantComponent,
    UserDraftComponent,
    UserDraftComposeComponent,
    UserArchiveComponent,
    UserTrashComponent,
    UserForgetComponent,
    UserResetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSummernoteModule,
    HttpClientModule,
    NgMultiSelectDropDownModule.forRoot(),
    CommonModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      closeButton: true,
      progressBar: true,
      progressAnimation: 'decreasing',
      positionClass: 'toast-top-center',
      timeOut: 3000,
      preventDuplicates: true,
    }),
    DataTablesModule,
    AvatarModule.forRoot({
      colors: avatarColors
    }),
    NgxPaginationModule
  ],
  providers: [MailboxserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
