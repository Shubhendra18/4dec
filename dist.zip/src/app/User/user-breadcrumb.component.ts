import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-user-breadcrumb',
  templateUrl: './user-breadcrumb.component.html',
  styles: []
})
export class UserBreadcrumbComponent implements OnInit {
  userId = localStorage.getItem("userToken");
  lastlogin: any;
  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.lastlogin = k['lastLogin'];
    });
  }

}
