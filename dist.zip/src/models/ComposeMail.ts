export class ComposeMailModel {
    Id: number;
    Priority: number;
    SMSAlert: boolean;
    ToUser: string;
    Subject: string;
    Message: string;
}
