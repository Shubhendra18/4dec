﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MandiParishadWebApi.Controllers
{
    [RoutePrefix("File")]
    public class FilehandlerController : ApiController
    {
        [Route("FileValidation")]
        public IHttpActionResult PostFileValidation()
        {
            var httpRequest = HttpContext.Current.Request;
            string UserProfilePic = null;
            var UserProfile = httpRequest.Files["ProfilePic"];
            String UserPicExt = Path.GetExtension(UserProfile.FileName);
            string mimetype = UserProfile.ContentType;

            if (mimetype == "image/jpeg" || mimetype == "image/jpg" || mimetype == "image/pjpeg"
                   || mimetype == "image/png" || mimetype == "application/x-jpg" || mimetype == "image/pipeg" || mimetype == "image/vnd.swiftview-jpeg"
                   || mimetype == "application/msword" || mimetype == "application/vnd.ms-excel" || mimetype == "application/pdf" || mimetype == "text/plain"
                   || mimetype == "application/vnd.ms-powerpoint" || mimetype == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                   || mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            {
                if ((UserPicExt.ToLower() == ".jpg" || UserPicExt.ToLower() == ".jpeg" || UserPicExt.ToLower() == ".pdf"
                || UserPicExt.ToLower() == ".png" || UserPicExt.ToLower() == ".doc" || UserPicExt.ToLower() == ".docx" ||
                UserPicExt.ToLower() == ".xls" || UserPicExt.ToLower() == ".xlsx" || UserPicExt.ToLower() == ".ppt" ||
                UserPicExt.ToLower() == ".pptx" || UserPicExt.ToLower() == ".txt"))
                {
                    if (UserProfile.ContentLength > 5242880)
                    {
                        return BadRequest("File Size Can not be exceeded More Than 5 MB");
                    }
                    else
                    {
                        return Ok("S");
                    }
                }
                else
                {
                    return BadRequest("File Extension Not Allowed");
                }
            }
            else
            {
                return BadRequest("File Extension Not Allowed");
            }
        }
    }
}
