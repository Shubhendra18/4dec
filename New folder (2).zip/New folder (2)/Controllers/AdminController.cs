﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Security;
using System.Web.SessionState;
using MandiParishadWebApi.Filters;
using MandiParishadWebApi.Models;
using MandiParishadWebApi.Repository;
using SRVTextToImage;

namespace MandiParishadWebApi.Controllers
{

    [RoutePrefix("Admin")]
    public class AdminController : ApiController
    {
        AdminContext da = new AdminContext();
        Common objCom = new Common();
        DisplayMessage displayMessage = new DisplayMessage();
        SessionManager sessionManager = new SessionManager();
        [Route("GetCaptcha")]
        public HttpResponseMessage GetCaptcha()
        {
            var resp = new HttpResponseMessage();
            string[] array = CaptchaImage.CreateRandomText(1);
            CaptchaRandomImage ci = new CaptchaRandomImage();
            string d1 = array[0].ToString();
            var cookie = new CookieHeaderValue("captchaToken", d1);
            cookie.Domain = Request.RequestUri.Host;
            cookie.Path = "/";
            cookie.Secure = false;
            cookie.HttpOnly = true;
            resp.Headers.AddCookies(new CookieHeaderValue[] { cookie });
            sessionManager.cap = d1;
            string d2 = array[1].ToString();
            ci.GenerateImage(d2 + " =", 150, 40, Color.Black, Color.White);
            var stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            resp.Content = new StreamContent(stream);
            resp.Content.Headers.ContentType =
        new MediaTypeHeaderValue("image/png");
            return resp;

        }
        [Route("AdminLoginn")]
        public IHttpActionResult PostAdminLogin(UserLogin mail)
        {
            string capvalue = sessionManager.cap.ToString();
            AfterUserLogin data = da.UserLogin(mail.officeName);
            if (data != null)
            {
                if (data.groupID.ToString() == "4")
                {
                    string dbpas = objCom.SingleHashing(mail.Password);
                    if (dbpas == data.password)
                    {
                        displayMessage.Message = "Login successfull";
                        displayMessage.Type = "s";
                        return Ok(new { displayMessage, data.officeName, data.userId });
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("Please Enter Valid Password") { { "Type", "w" } };
                        return Content(HttpStatusCode.BadRequest, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Unauthorised Login") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);
                }
            }
            else
            {
                HttpError myCustomError = new HttpError("Please Enter Valid UserName") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("LastLogin/{userId}")]
        public IHttpActionResult GetLastlogin(Int64 userId)
        {
            GetUserProfileInfo data = da.LastLoginInfo(userId);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("UpdateProfile")]
        public IHttpActionResult PutUpdateProfile()
        {
            string imageName = null;
            var httpRequest = HttpContext.Current.Request;
            var postedFile = httpRequest.Files["ProfilePic"];
            imageName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
            imageName = imageName + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
            var filePath = HttpContext.Current.Server.MapPath("~/UserProfile/" + imageName);
            postedFile.SaveAs(filePath);
            GetUserProfileInfo data = da.UpdateProfile(Convert.ToInt64(httpRequest["userId"]), httpRequest["mobileNo"], imageName);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GroupMaster")]
        public IHttpActionResult GetGroup()
        {
            List<GroupMaster> data = da.GetGroupMaster().OrderBy(k => k.groupName).ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("AddUpdateGroupMaster")]
        public IHttpActionResult PostGroup(AddUpdateUserMaster groupMasterData)
        {
            var data = da.AddUpdateGroupName(groupMasterData.transId, groupMasterData.groupName, groupMasterData.userId);
            if (data.ToString() == "0")
            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Inserted") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("DeleteGroupMaster/{id}")]
        public IHttpActionResult DeleteGroup([FromUri]int id)
        {
            var data = da.DeleteGroup(id);
            if (data.ToString() == "0")
            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Deleted") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("AddUser")]
        public IHttpActionResult PostNewUser(AddUser userData)
        {
            var DisplayPassword = CGeneral.GetRendomPassword(8);
            userData.password = objCom.SingleHashing(DisplayPassword);
            String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserCredentialsMsg"]).Replace("[ID]", userData.officeName).Replace("[Pass]", DisplayPassword);
            var data = da.AddUser(userData);
            if (data.ToString() == "0")
            {
                SMSSender.SMSSend(Msg, userData.mobileNo);
                return Ok("User has been registred successfully!");
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Inserted") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("CheckUserName/{UserName}")]
        public IHttpActionResult GetCheckUserName([FromUri] string UserName)
        {
            var data = da.CheckUserName(UserName);
            if (data.ToString() == "0")

            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("This user name already exist. Please try with another username!") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetUsersCount")]
        public IHttpActionResult PostGetUsersCount(int groupId)
        {
            var data = da.GetUsersCount(groupId);
            if (data.ToString() == "0")

            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("You have completed maximum limit of user creation!") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetUserBygroup/{groupId}")]
        public IHttpActionResult GetUserBygroup(int groupId)
        {
            var data = da.GetGroupUsers(groupId);
            if (data != null)

            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No User Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("ComposeMail")]
        public IHttpActionResult PostComposeMail(MailBox mailBox)
        {
            string data = "";

            foreach (var k in mailBox.Rid)
            {
                // data = da.ComposeMail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, k.userId);
            }
            if (data == "success")
            {
                return Ok("Mail Send");
            }
            else
            {
                HttpError myCustomError = new HttpError("Unsuccessfull") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
            //Object data = 0;
            //Int64 Mailid = da.ComposeMail(mailBox);
            //if (Mailid > 0)
            //{
            //    foreach (var k in mailBox.Rid)
            //    {
            //        data = da.ComposeMailInfo(Mailid, k.userId, mailBox.Sid);
            //    }
            //    if (Convert.ToInt32(data) > 0)
            //    {
            //        data = "Mail Send";
            //    }
            //    return Ok(data);
            //}
            //else
            //{
            //    HttpError myCustomError = new HttpError("Unsuccessfull") { { "Type", "w" } };
            //    return Content(HttpStatusCode.BadRequest, myCustomError);
            //}
        }


        [Route("GetGroupUserForManage/{groupId}")]
        public IHttpActionResult GetGroupUserForManage(int groupId)
        {
            var data = da.GetGroupUsersforManage(groupId);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("updateUserMaster")]
        public IHttpActionResult PutupdateUserMaster(UpdateuserModel model)
        {
            string msg = da.updateUserMaster(model);
            if (msg == "Success")
            {
                return Ok(msg);
            }
            else
            {
                HttpError myCustomError = new HttpError("Failed to Update No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetLastLogin")]
        public IHttpActionResult GetLastLogin()
        {
            List<LastLoginModel> data = da.GetlastloginReport();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("CheckGroupName/{groupName}")]
        public IHttpActionResult GetChecgroupName([FromUri] string groupName)
        {
            var data = da.CheckGroupName(groupName);
            if (data.ToString() == "0")

            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("This Group name already exist. Please try with another groupname!") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("SendReceiveStats")]
        public IHttpActionResult GetSendReceiveStats()
        {
            List<SendAndReceiveModel> data = da.GetSendAndReceiveMsgs();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("UsedUser")]
        public IHttpActionResult GetuseduserList()
        {
            List<UsedUser> data = da.GetUsedUser();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("NotUsedUser")]
        public IHttpActionResult GetNotuseduserList()
        {
            List<UsedUser> data = da.GetNotUsedUser();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        [Route("ActiveDeactiveUser")]
        public IHttpActionResult PostActiveDeactiveUser(ActiveDeactive activeDeactive)
        {
            string data = da.ActiveDeactiveUser(activeDeactive);
            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetAllOffice")]
        public IHttpActionResult GetAllOffice()
        {
            List<GetOfficeName> data = da.OfficeName().OrderBy(k => k.officeName).ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("MsgReportByOfficeName/{userId}")]
        public IHttpActionResult GetMsgReportByOfficeName(Int64 userId)
        {
            List<ReportByOfficeName> data = da.ReportByOfficeName(userId).ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("MsgReportBySuject/{subject}")]
        public IHttpActionResult GetMsgReportByOfficeName(string subject)
        {
            List<ReportByOfficeName> data = da.ReportBysubject(subject).ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("MsgReportByDate")]
        public IHttpActionResult PostMsgReportByDate(ReportByDate date)
        {
            List<ReportByOfficeName> data = da.ReportByDate(date).ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("Broadcast")]
        public IHttpActionResult PostBroadcast()
        {
            string imageName = null;
            string BrodId = DateTime.Now.ToString("yyMMddHHmmssff");
            string data = "";
            var httpRequest = HttpContext.Current.Request;
            BroadCast broadCast = new BroadCast();
            broadCast.BrodId = BrodId;
            broadCast.Sid = Convert.ToInt64(httpRequest["Sid"]);
            broadCast.Subject = httpRequest["Subject"];
            broadCast.Message = httpRequest["Message"];
            var postedFile = httpRequest.Files["ProfilePic"];

            imageName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
            imageName = imageName + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
            var filePath = HttpContext.Current.Server.MapPath("~/Broadcastpics/" + imageName);
            postedFile.SaveAs(filePath);
            string[] rid = httpRequest["Rid"].Split(',');
            string msgid = DateTime.Now.ToString("yyMMddHHmmssff");
            foreach (var k in rid)
            {
                data = da.BroadcastMsg(broadCast.Sid, Convert.ToInt64(k), BrodId, broadCast.Message, broadCast.Subject, imageName);
            }
            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("BroadcastMessage/{rid}")]
        public IHttpActionResult GetBroadcast(Int64 rid)
        {
            BroadCastMessage data = da.ViewBroadcastmsg(rid);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("MarkBroadcastMessageSeen/{rowid}")]
        public IHttpActionResult GetBroadcastMessageSeen(Int64 rowid)
        {
            string data = da.BroadcastmsgSeen(rowid);
            if (data == "success")
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
    }
}
