import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { MailboxserviceService } from '../mailboxservice.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-broadcast',
  templateUrl: './broadcast.component.html',
  styles: []
})
export class BroadcastComponent implements OnInit {
  defaultgroup = "0";
  defaultname = "0";
  groupData: any = [];
  public users: any = [];
  Sid = localStorage.getItem("Token");
  dropdownList: any = [];
  selectedItems = [];
  dropdownSettings = {};
  files: File[] = [];
  rId: any[] = [];
  fileToUpload: File = null;
  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });


    this.dropdownSettings = {
      singleSelection: false,
      data: 'dropdownList',
      idField: 'userId',
      textField: 'officeName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times']
  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.dropdownList = k;
    });
  }

  sendBroadcast(broadcast) {
    this.service.BroadcastPost(this.Sid, broadcast.value.Rid, broadcast.value.Subject, this.fileToUpload, broadcast.value.Message).subscribe((data: any) => {
      if (data == "success") {
        this.toastr.success('Message Sent', 'Success');
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.toastr.error('Something went wrong', 'Error');
      };
    });

  }
  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    this.service.FileHandle(this.fileToUpload).subscribe(
      data => {
        this.fileToUpload = file.item(0);
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          Swal.fire({
            icon: 'warning',
            title: err.error.message,
            text: "Warning",
          })
        };
      }
    );
  }
  onItemSelect(item: any) {
    this.rId.push(item)
  }
  onSelectAll(items: any) {
    for (let index = 0; index < items.length; index++) {
      const element = items[index];
      this.rId.push(element)
    }
  }
  onItemDeSelect(item: any) {
    this.rId.splice(item);
  }



}
