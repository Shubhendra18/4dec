import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['../user/user-login.component.css']

})
export class AdminLoginComponent implements OnInit {
  captchaKey: string = "";
  captchaerror = false;
  captcha: any = "";
  captchapic: any = "http://localhost:4876/Admin/GetCaptcha";
  constructor(private service: MailboxserviceService, private router: Router, private cookieService: CookieService) { }

  ngOnInit() {
  }

  refreshcaptcha() {
    this.captchapic = "http://localhost:4876/Admin/GetCaptcha?=" + Math.random();
  }

  login(loginData) {
    if (loginData.value.Captcha === this.cookieService.get('captchaToken')) {
      this.service.AdminLogin(loginData.value).subscribe((data: any) => {
        localStorage.setItem('Token', data.userId);
        this.router.navigate(['/dashboard']);
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          Swal.fire({
            icon: 'warning',
            title: err.error.message,
            text: "Warning",
          })
        };
      });
    }
    else {
      Swal.fire({
        icon: 'warning',
        title: 'Invalid Captcha Try Again!',
        text: "Warning",
      })
    }
  }
}