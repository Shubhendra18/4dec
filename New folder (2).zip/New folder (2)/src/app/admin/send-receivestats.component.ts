import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-send-receivestats',
  templateUrl: './send-receivestats.component.html',
  styles: []
})
export class SendReceivestatsComponent implements OnInit {
  sendrecstats: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  constructor(private service: MailboxserviceService) { }

  ngOnInit() {
    this.service.GetsendreceiveStats().subscribe(k => {
      this.sendrecstats = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers'
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}
