import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-navbar',
  templateUrl: './user-navbar.component.html',
  styles: []
})
export class UserNavbarComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
    //$.getScript('assets/js/nifty.min.js');
  }
  // ngAfterViewInit() {
  //   $.getScript('assets/js/nifty.min.js');

  // }
  Logout() {
    localStorage.removeItem('userToken');
    this.router.navigate(['/login']);
  }
}