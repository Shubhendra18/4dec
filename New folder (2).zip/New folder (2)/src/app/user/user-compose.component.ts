import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { MailboxserviceService } from '../mailboxservice.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-user-compose',
  templateUrl: './user-compose.component.html',
  styles: []
})
export class UserComposeComponent implements OnInit {
  defaultgroup = "0";
  defaultname = "0";
  groupData: any = [];
  public users: any = [];
  Sid = localStorage.getItem("userToken");
  dropdownList: any = [];
  selectedItems = [];
  dropdownSettings = {};
  files: File[] = [];
  rId: any[] = [];
  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });


    this.dropdownSettings = {
      singleSelection: false,
      data: 'dropdownList',
      idField: 'userId',
      textField: 'officeName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times'],
    disableDragAndDrop: true,
    tabDisable: false
  }

  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.dropdownList = k;
    });
  }

  saveasdraft(mailBox) {
    this.service.MoveToDraft(mailBox.value.Priority, false, mailBox.value.Subject, mailBox.value.Message, mailBox.value.Sid).subscribe((data: any) => {
      if (data == "success") {
        this.toastr.success('Moved to Draft', 'Success');
        this.files.length = 0;
        this.rId.length = 0;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.toastr.error('Something went wrong', 'Error');
      };
    });

  }
  onItemSelect(item: any) {
    this.rId.push(item)
  }
  onSelectAll(items: any) {
    for (let index = 0; index < items.length; index++) {
      const element = items[index];
      this.rId.push(element)
    }
  }
  onItemDeSelect(item: any) {
    this.rId.splice(item);
  }

  uploadFile(event) {
    for (let index = 0; index < event.length; index++) {
      const element = event[index];
      this.service.FileHandle(element).subscribe(
        data => {
          this.files.push(element);
        }, (err: HttpErrorResponse) => {
          if (err.status === 400) {
            Swal.fire({
              icon: 'warning',
              title: err.error.message,
              text: "Warning",
            })
          };
        }
      );
    }
  }







  deleteAttachment(index) {
    this.files.splice(index, 1)
  }
  profileUpdate(mailBox) {
    this.service.Attachmentsfiles(this.files, mailBox.value.Priority, false, mailBox.value.Subject, mailBox.value.Message, mailBox.value.Sid, this.rId).subscribe((data: any) => {
      if (data == "success") {
        this.toastr.success('Mail Sent!', 'Success');
        this.files.length = 0;
        this.rId.length = 0;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status == 400) {
        this.toastr.error('Something went wrong', 'Error');
      };
    });;
  }

}
