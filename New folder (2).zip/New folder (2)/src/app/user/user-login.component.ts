import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MailboxserviceService } from '../mailboxservice.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  defaultgroup = "0";
  defaultname = "0";
  groupData: any = [];
  users: any = [];
  captchaKey: string = "";
  captchaerror = false;
  captchapic: any = "http://localhost:4876/Admin/GetCaptcha";

  constructor(private service: MailboxserviceService, private toaster: ToastrService, private router: Router, private cookieService: CookieService) {
  }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });


  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.users = k;
    });
  }
  refreshcaptcha() {
    this.captchapic = "http://localhost:4876/Admin/GetCaptcha?=" + Math.random();
  }

  login(loginData) {
    if (loginData.value.Captcha === this.cookieService.get('captchaToken')) {
      this.service.UserLogin(loginData.value).subscribe((data: any) => {
        localStorage.setItem('userToken', data.userId);
        this.router.navigate(['/inbox']);
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          Swal.fire({
            icon: 'warning',
            title: err.error.message,
            text: "Warning",
          })
        };
      });
    }
    else {
      Swal.fire({
        icon: 'warning',
        title: 'Invalid Captcha Try Again!',
        text: "Warning",
      })
    }
  }
}
