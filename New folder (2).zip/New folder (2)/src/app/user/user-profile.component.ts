
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styles: []
})
export class UserProfileComponent implements OnInit {
  divprofile = true;
  divpass = true;
  imageUrl: string = "/assets/img/default.png";
  defaultPic: string;
  fileToUpload: File = null;
  profileinfo: any = {};
  userId = localStorage.getItem("userToken");
  OldPassincorrect: boolean = false;
  constructor(private service: MailboxserviceService, private toastr: ToastrService, private router: Router) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.profileinfo = k;
      if (k['profilePic'] != null) {
        this.defaultPic = 'http://localhost:4876/UserProfile/' + k['profilePic'];
      }
    });
    this.divprofile = true;
    this.divpass = true;
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  profileUpdate(mobileNo, ProfilePic, userId) {
    this.service.UpdateProfile(mobileNo.value, this.fileToUpload, userId.value).subscribe(
      data => {
        this.toastr.success('Profile Updated!', 'Success');
        this.defaultPic = 'http://localhost:4876/UserProfile/' + data['profilePic'];
        this.profileinfo = data;
        ProfilePic.value = null;
        this.imageUrl = "/assets/img/default.png";
      }
    );
  }

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    var reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }

  changeUserPassword(userId, Password) {
    this.service.changePassword(userId.value, Password.value).subscribe(
      data => {
        this.toastr.success('Password Changed!', 'Success');
      }
    );
  }
  onChange(userId, OldPass) {
    this.service.CheckOldPass(userId.value, OldPass.value).subscribe((data: any) => {
      if (data == "success") {
        this.OldPassincorrect = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: err.error.message,
          text: "Warning",
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'ok Try Again!'
        }).then((result) => {
          if (result.value) {
            this.OldPassincorrect = true;
          }
        })
      };
    });
  }

  profile() {
    this.divprofile = false;
    this.divpass = true;
  }
  password() {
    this.divprofile = true;
    this.divpass = false;
  }
  close() {
    this.divprofile = true;
    this.divpass = true;
  }
}

