import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserInboxComponent } from './user/user-inbox.component';
import { UserComposeComponent } from './user/user-compose.component';
import { UserLoginComponent } from './user/user-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { AdminDashboardComponent } from './admin/admin-dashboard.component';
import { ManageGroupComponent } from './admin/manage-group.component';
import { ManageUserComponent } from './admin/manage-user.component';
import { UserlistComponent } from './admin/user-list.component';
import { ResetPassComponent } from './admin/reset-pass.component';
import { BroadcastComponent } from './admin/broadcast.component';
import { SendReceivestatsComponent } from './admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './admin/usernotusingmboard.component';
import { LastloginComponent } from './admin/lastlogin.component';
import { MsgReportComponent } from './admin/msg-report.component';
import { AdminprofileComponent } from './admin/admin-profile.component';
import { UserInboxInfoComponent } from './user/user-inbox-info.component';
import { UserSendComponent } from './user/user-send.component';
import { UserImportantComponent } from './user/user-important.component';
import { UserDraftComponent } from './user/user-draft.component';
import { UserDraftComposeComponent } from './user/user-draft-compose.component';
import { UserArchiveComponent } from './user/user-archive.component';
import { UserTrashComponent } from './user/user-trash.component';
import { UserForgetComponent } from './user/user-forget.component';
import { UserResetComponent } from './user/user-reset.component';
import { UserProfileComponent } from './user/user-profile.component';
import { SentmailDesComponent } from './user/sentmail-des.component';
import { ErrorpageComponent } from './common/errorpage.component';
import { ImportantdetailsComponent } from './user/importantdetails.component';
import { ArchivedetailsComponent } from './user/archivedetails.component';
import { TrashdetailsComponent } from './user/trashdetails.component';
import { AdminmailboxComponent } from './admin/adminmailbox.component';
import { AdminmailboxinfoComponent } from './admin/adminmailboxinfo.component';
import { AdmincreateComponent } from './admin/admincreate.component';
import { AdminsentmailComponent } from './admin/adminsentmail.component';
import { AdminsentdetailsComponent } from './admin/adminsentdetails.component';
import { AdminimportantComponent } from './admin/adminimportant.component';
import { AdminimportantinfoComponent } from './admin/adminimportantinfo.component';
import { AdmindraftComponent } from './admin/admindraft.component';
import { AdmindraftcomComponent } from './admin/admindraftcom.component';
import { AdminarchiveComponent } from './admin/adminarchive.component';
import { AdminarchiveinfoComponent } from './admin/adminarchiveinfo.component';
import { AdminartrashComponent } from './admin/adminartrash.component';
import { AdminartrashinfoComponent } from './admin/adminartrashinfo.component';


const routes: Routes = [
  //********************User Routes************************/
  { path: 'login', component: UserLoginComponent },
  { path: 'inbox', component: UserInboxComponent },
  { path: 'details/:id', component: UserInboxInfoComponent },
  { path: 'compose', component: UserComposeComponent },
  { path: 'sent', component: UserSendComponent },
  { path: 'sentDetails/:messageid', component: SentmailDesComponent },
  { path: 'important', component: UserImportantComponent },
  { path: 'importantinfo/:impid', component: ImportantdetailsComponent },
  { path: 'draft', component: UserDraftComponent },
  { path: 'draftcom/:mailid', component: UserDraftComposeComponent },
  { path: 'archive', component: UserArchiveComponent },
  { path: 'archiveinfo/:archid', component: ArchivedetailsComponent },
  { path: 'trash', component: UserTrashComponent },
  { path: 'trashinfo/:trashid', component: TrashdetailsComponent },
  { path: 'forget', component: UserForgetComponent },
  { path: 'reset', component: UserResetComponent },
  { path: 'profile', component: UserProfileComponent },


  //********************Admin Login*************************/
  { path: 'admin', component: AdminLoginComponent },
  { path: 'dashboard', component: AdminDashboardComponent },
  { path: 'managegroup', component: ManageGroupComponent },
  { path: 'manageuser', component: ManageUserComponent },
  { path: 'userlist', component: UserlistComponent },
  { path: 'resetPassword', component: ResetPassComponent },
  { path: 'broadcast', component: BroadcastComponent },
  { path: 'statistics', component: SendReceivestatsComponent },
  { path: 'usernoactivated', component: UsernotusingmboardComponent },
  { path: 'lastloginrpt', component: LastloginComponent },
  { path: 'messagerpt', component: MsgReportComponent },
  { path: 'adminprofile', component: AdminprofileComponent },

  { path: 'mailbox', component: AdminmailboxComponent },
  { path: 'mailinfo/:aid', component: AdminmailboxinfoComponent },
  { path: 'create', component: AdmincreateComponent },
  { path: 'sentmail', component: AdminsentmailComponent },
  { path: 'sendDetails/:amessageid', component: AdminsentdetailsComponent },
  { path: 'aimportant', component: AdminimportantComponent },
  { path: 'aimportantinfo/:aimpid', component: AdminimportantinfoComponent },
  { path: 'admindraft', component: AdmindraftComponent },
  { path: 'admindraftcom/:amailid', component: AdmindraftcomComponent },
  { path: 'adminarchive', component: AdminarchiveComponent },
  { path: 'adminarchiveinfo/:aarchid', component: AdminarchiveinfoComponent },
  { path: 'admintrash', component: AdminartrashComponent },
  { path: 'admintrashinfo/:atrashid', component: AdminartrashinfoComponent },
  //********************Default************************/
  { path: 'error', component: ErrorpageComponent },
  { path: '', component: UserLoginComponent },
  { path: '**', redirectTo: '/error', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
