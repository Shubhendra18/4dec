
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';


@Component({
  selector: 'app-trashdetails',
  templateUrl: './trashdetails.component.html',
  styles: []
})
export class TrashdetailsComponent implements OnInit {
  Rid = localStorage.getItem("userToken");
  private maildetails: any = {};
  attachments: any = [];
  mailreplies: any = [];

  attachmentcount: number = 0;
  senderid: any;
  receiverid: any;
  messageID: any;
  constructor(private service: MailboxserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      var mailDes = { "mailId": params.get('trashid'), "rid": this.Rid };
      this.service.getmailDetails(mailDes).subscribe(k => {
        this.maildetails = k;
        this.senderid = k['rid'];
        this.receiverid = k['userId'];
        this.messageID = k['messageID'];

      })
      this.service.getattachments(mailDes).subscribe(k => {
        this.attachments = k;
        this.attachmentcount = this.attachments.length;
      })
      var sendMailDes = { "MessageId": params.get('trashid'), "userId": this.Rid };
      this.service.ShowMailReply(sendMailDes).subscribe(k => {
        this.mailreplies = k;
      })
    });

  }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times']
  }
  SendReply(MailReply) {
    this.service.SendMailReply(MailReply.value).subscribe();
  }
}
