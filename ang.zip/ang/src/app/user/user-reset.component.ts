import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-reset',
  templateUrl: './user-reset.component.html',
  styles: []
})
export class UserResetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
