import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
@Component({
  selector: 'app-adminsentdetails',
  templateUrl: './adminsentdetails.component.html',
  styles: []
})
export class AdminsentdetailsComponent implements OnInit {
  Rid = localStorage.getItem("Token");
  private maildetails: any = {};
  attachments: any = [];
  attachmentcount: number = 0;
  constructor(private service: MailboxserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      var sendMailDes = { "userId": this.Rid, "messageid": params.get('amessageid') };
      this.service.GetSentMailDetails(sendMailDes).subscribe(k => {
        this.maildetails = k;
      })
      // this.service.getattachments(mailDes).subscribe(k => {
      //   this.attachments = k;
      //   this.attachmentcount = this.attachments.length;
      // })
    });
  }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times']
  }

}
