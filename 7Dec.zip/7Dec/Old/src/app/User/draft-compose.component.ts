import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-draft-compose',
  templateUrl: './draft-compose.component.html',
  styles: []
})
export class DraftComposeComponent implements OnInit {
  Rid = localStorage.getItem("userToken");
  private maildetails: any = {};

  constructor(private service: ApihandlerService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      var mailDes = { "mailId": params.get('mailid'), "rid": this.Rid };
      this.service.getdraftDetails(mailDes).subscribe(k => {
        this.maildetails = k;
      })
    });
  }

}
