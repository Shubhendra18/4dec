import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-archive',
  templateUrl: './user-archive.component.html',
  styles: []
})
export class UserArchiveComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  Rid = localStorage.getItem("userToken");

  constructor(private service: ApihandlerService, private toastr: ToastrService) { }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }
  ngOnInit() {
    this.service.allMailFromArchive(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  BackToInbox(mailId) {
    var moveToInbox = { "mailId": mailId, "flag": 0 };
    this.service.backToInbox(moveToInbox).subscribe(k => {
      if (k == "success") {
        this.toastr.success('moved To Inbox!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Inbox!', 'Error');
      }
    });
  }
}
