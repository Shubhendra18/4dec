import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['../../assets/css/loginpage.css', '../../assets/css/bootstrap.min.3.37.css']

})
export class ResetpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
