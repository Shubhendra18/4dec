import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-user-navbar',
  templateUrl: './user-navbar.component.html',
  styles: []
})
export class UserNavbarComponent implements OnInit {
  pic = true;
  defaultPic = "";
  fullName = "";
  userId = localStorage.getItem("userToken");

  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      if (k['profilePic'] != null) {
        this.defaultPic = 'http://localhost:4876/UserProfile/' + k['profilePic'];
        this.fullName = "";
      }
      else {
        this.fullName = k['officeName'];
        this.defaultPic = "";
      }
    });
  }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }

}
