import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { ToastrService } from 'ngx-toastr';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-user-draft',
  templateUrl: './user-draft.component.html',
  styles: []
})
export class UserDraftComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  Rid = localStorage.getItem("userToken");

  constructor(private service: ApihandlerService, private toastr: ToastrService, private route: Router) { }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }
  ngOnInit() {
    this.service.allMailFromDraft(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  composeagain(mailId) {
    this.route.navigate(['/draftcom', mailId]);
  }
}
