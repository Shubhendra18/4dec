import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['../../assets/css/loginpage.css', '../../assets/css/bootstrap.min.3.37.css']

})
export class ForgetpasswordComponent implements OnInit {
  divforget = false;
  divotp = true;
  divreset = true;
  MobileNo: string = '';
  userId: number;
  constructor(private service: ApihandlerService, private router: Router) { }

  ngOnInit() {
  }
  sendotp(mobileNo) {
    this.service.forgetPassword(mobileNo).subscribe((data: any) => {
      this.MobileNo = mobileNo;
      if (data.displayMessage.type = "s") {
        Swal.fire({
          icon: 'success',
          title: 'OTP Sent Successfully',
          text: data.displayMessage.message,
        })
        this.divforget = true;
        this.divotp = false;
        this.divreset = true;
      }
      else {
        this.divforget = false;
        this.divotp = true;
        this.divreset = true;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: 'warning',
          text: err.error.message,
        })
      };
    });
  }
  otpverify(OTP) {
    this.service.otpVerification(this.MobileNo, OTP).subscribe((data: any) => {
      if (data.verification == "verified") {
        this.userId = data.userId;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'OTP Verified Successfully',
        });
        this.divforget = true;
        this.divotp = true;
        this.divreset = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: 'warning',
          text: err.error.message,
        })
        this.divforget = true;
        this.divotp = false;
        this.divreset = true;
      };
    });
  }
  resetpassword(Password) {
    this.service.changePassword(this.userId, Password).subscribe(k => {
      if (k == "success") {
        Swal.fire({
          title: 'Password Changed',
          text: "Password Changes Successfully!",
          icon: 'success',
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'Go Back To Login!'
        }).then((result) => { 
          if (result.value) {
            this.router.navigate(['/user']);
          }
        })
      }
    })
  }
  backtoForget() {
    this.divforget = false;
    this.divotp = true;
    this.divreset = true;
  }
}
