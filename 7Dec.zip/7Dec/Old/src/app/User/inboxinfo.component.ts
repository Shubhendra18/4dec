import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-inboxinfo',
  templateUrl: './inboxinfo.component.html',
  styles: []
})
export class InboxinfoComponent implements OnInit {
  Rid = localStorage.getItem("userToken");
  private maildetails: any = {};
  attachments: any = [];
  constructor(private service: ApihandlerService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      console.log(params.get('id'))
      var mailDes = { "mailId": params.get('id'), "rid": this.Rid };
      this.service.getmailDetails(mailDes).subscribe(k => {
        this.maildetails = k;
      })
      this.service.getattachments(mailDes).subscribe(k => {
        this.attachments = k;
      })
    });
  }
  config = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote'],
      [{ 'header': 1 }, { 'header': 2 }],               // custom button values
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
      [{ 'direction': 'rtl' }],                         // text direction

      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
    ]
  };
}
