import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styles: []
})
export class NavbarComponent implements OnInit {
  pic = true;
  defaultPic = "";
  fullName = "";
  userId = localStorage.getItem("Token");

  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      if (k['profilePic'] != null) {
        this.defaultPic = 'http://localhost:4876/UserProfile/' + k['profilePic'];
        this.fullName = "";
      }
      else {
        this.fullName = k['officeName'];
        this.defaultPic = "";
      }
    });
  }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }

}
