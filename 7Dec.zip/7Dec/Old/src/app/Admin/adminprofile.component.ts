import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrls: ['./adminprofile.component.css']
})
export class AdminprofileComponent implements OnInit {
  divprofile = true;
  divpass = true;
  imageUrl: string = "/assets/images/default.png";
  defaultPic: string = "/assets/images/user.jpg";
  fileToUpload: File = null;
  profileinfo: any = {};
  userId = localStorage.getItem("Token");
  constructor(private service: ApihandlerService, private toastr: ToastrService, private router: Router) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.profileinfo = k;
      if (k['profilePic'] != null) {
        this.defaultPic = 'http://localhost:4876/UserProfile/' + k['profilePic'];
      }
      else {
        this.defaultPic;
      }
    });
  }

  profileUpdate(mobileNo, ProfilePic, userId) {
    this.service.UpdateProfile(mobileNo.value, this.fileToUpload, userId.value).subscribe(
      data => {
        this.toastr.success('Profile Updated!', 'Success');
        this.defaultPic = 'http://localhost:4876/UserProfile/' + data['profilePic'];
        this.profileinfo = data;
        ProfilePic.value = null;
        this.imageUrl = "/assets/images/default.png";
      }
    );
  }

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    var reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }















  profile() {
    this.divprofile = false;
    this.divpass = true;
  }
  password() {
    this.divprofile = true;
    this.divpass = false;
  }
  close() {
    this.divprofile = true;
    this.divpass = true;
  }
}
