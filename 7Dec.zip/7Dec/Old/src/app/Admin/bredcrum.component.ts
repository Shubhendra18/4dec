
import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-bredcrum',
  templateUrl: './bredcrum.component.html',
  styles: []
})
export class BredcrumComponent implements OnInit {
  userId = localStorage.getItem("Token");
  lastlogin: any;
  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.lastlogin = k['lastLogin'];
    });
  }

}
