import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class MailboxserviceService {
  private baseUrl = "http://localhost:4876"

  constructor(private http: HttpClient) { }
  UserLogin(loginData) {
    return this.http.post(this.baseUrl + "/Admin/UserLogin", loginData);
  }
  UserLastLogin(userId) {
    return this.http.get(this.baseUrl + "/Admin/LastLogin/" + userId);
  }

  UpdateProfile(mobileNo: string, fileToUpload: File, userId) {
    const formData: FormData = new FormData();
    formData.append('ProfilePic', fileToUpload, fileToUpload.name);
    formData.append('mobileNo', mobileNo);
    formData.append('userId', userId);

    return this.http.put(this.baseUrl + "/Admin/UpdateProfile/", formData);
  }
  GetCaptcha() {
    return this.http.get(this.baseUrl + "/Admin/GetCaptcha");
  }

  Attachmentsfiles(fileToUpload, Priority, SMS, Subject, Message, Sid, Rid) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("Attachment[]", fileToUpload[i]);
    }
    for (let i = 0; i < Rid.length; i++) {
      formData.append("Rid", Rid[i].userId);
    }
    formData.append('Priority', Priority);
    formData.append('SMS', SMS);
    formData.append('Subject', Subject);
    formData.append('Message', Message);
    formData.append('Sid', Sid);
    //formData.append('Rid', Rid);

    return this.http.post(this.baseUrl + "/User/ComposeMailWithAttachment", formData);
  }


  GroupMaster() {
    return this.http.get(this.baseUrl + "/Admin/GroupMaster");
  }
  AddUpdateGroupMaster(groupMasterData) {
    return this.http.post(this.baseUrl + "/Admin/AddUpdateGroupMaster", groupMasterData);
  }
  DeleteGroupMaster(groupId) {
    return this.http.delete(this.baseUrl + "/Admin/DeleteGroupMaster/" + groupId.groupId);
  }
  composemail(mailBox) {
    return this.http.post(this.baseUrl + "/Admin/ComposeMail", mailBox);
  }
  GetGroupUserForManage(groupId) {
    return this.http.get(this.baseUrl + "/Admin/GetGroupUserForManage/" + groupId);
  }
  updateUserMaster(ManageUserData) {
    return this.http.put(this.baseUrl + "/Admin/updateUserMaster/", ManageUserData);
  }
  GetLastLogin() {
    return this.http.get(this.baseUrl + "/Admin/GetLastLogin");
  }
  chkgroupName(groupName) {
    return this.http.get(this.baseUrl + "/Admin/CheckGroupName/" + groupName);
  }
  GetsendreceiveStats() {
    return this.http.get(this.baseUrl + "/Admin/SendReceiveStats");
  }
  GetUsedUser() {
    return this.http.get(this.baseUrl + "/Admin/UsedUser");
  }
  GetNotUsedUser() {
    return this.http.get(this.baseUrl + "/Admin/NotUsedUser");
  }
  //****************************************************User Api Call*********************************************************************/
  chkName(UserName) {
    return this.http.get(this.baseUrl + "/Admin/CheckUserName/" + UserName);
  }
  AddUser(addUser) {
    return this.http.post(this.baseUrl + "/Admin/AddUser", addUser);
  }
  GetUserBygroup(groupId) {
    return this.http.get(this.baseUrl + "/Admin/GetUserBygroup/" + groupId);
  }
  getmail(Rid) {
    return this.http.get(this.baseUrl + "/User/InboxMail/" + Rid);
  }
  getmailDetails(mailDes) {
    return this.http.post(this.baseUrl + "/User/MailDetails", mailDes);
  }
  moveToTrash(SelectedIDs: any = []) {
    return this.http.post(this.baseUrl + "/User/MoveToTrash", SelectedIDs);
  }
  allMailsmoveToTrash(Rid) {
    return this.http.delete(this.baseUrl + "/User/AllMailMoveToTrash/" + Rid);
  }
  allMailFromTrash(Rid) {
    return this.http.get(this.baseUrl + "/User/FromTrash/" + Rid);
  }
  deleteFromTrash(MailId) {
    return this.http.delete(this.baseUrl + "/User/DeleteFromTrash/" + MailId);
  }


  moveToArchive(SelectedIDs: any = []) {
    return this.http.post(this.baseUrl + "/User/MoveToArchive", SelectedIDs);
  }
  allMailsmoveToArchive(Rid) {
    return this.http.get(this.baseUrl + "/User/AllMailMoveToArchive/" + Rid);
  }
  allMailFromArchive(Rid) {
    return this.http.get(this.baseUrl + "/User/FromArchive/" + Rid);
  }
  backToInbox(moveToInbox) {
    return this.http.post(this.baseUrl + "/User/MovebackToInbox", moveToInbox);
  }
  moveToImportant(mailId) {
    return this.http.get(this.baseUrl + "/User/MoveToImportant/" + mailId);
  }
  allMailFromImportant(Rid) {
    return this.http.get(this.baseUrl + "/User/AllMailFromImportant/" + Rid);
  }
  forgetPassword(mobileNo) {
    return this.http.get(this.baseUrl + "/User/ForgetPassword/" + mobileNo);
  }
  otpVerification(mobileNo, OTP) {
    var verifyOTP = { 'mobileNo': mobileNo, 'OTP': OTP }
    return this.http.post(this.baseUrl + "/User/VerifyOTP", verifyOTP);
  }
  changePassword(userId, Password) {
    var changePassword = { 'userId': userId, 'Password': Password }
    return this.http.post(this.baseUrl + "/User/ChangePassword", changePassword);
  }
}
