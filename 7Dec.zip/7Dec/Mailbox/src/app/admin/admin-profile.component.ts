import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-profile',
  templateUrl: './admin-profile.component.html',
  styles: []
})
export class AdminProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
