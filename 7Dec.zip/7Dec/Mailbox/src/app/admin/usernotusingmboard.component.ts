import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usernotusingmboard',
  templateUrl: './usernotusingmboard.component.html',
  styles: []
})
export class UsernotusingmboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
