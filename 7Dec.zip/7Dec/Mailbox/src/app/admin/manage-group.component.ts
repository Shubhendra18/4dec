import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-group',
  templateUrl: './manage-group.component.html',
  styles: []
})
export class ManageGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
