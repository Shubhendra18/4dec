import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lastlogin',
  templateUrl: './lastlogin.component.html',
  styles: []
})
export class LastloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
