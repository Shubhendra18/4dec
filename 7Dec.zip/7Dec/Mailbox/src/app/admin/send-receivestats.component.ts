import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-receivestats',
  templateUrl: './send-receivestats.component.html',
  styles: []
})
export class SendReceivestatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
