import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserInboxComponent } from './user/user-inbox.component';
import { UserComposeComponent } from './user/user-compose.component';
import { UserLoginComponent } from './user/user-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { AdminDashboardComponent } from './admin/admin-dashboard.component';
import { ManageGroupComponent } from './admin/manage-group.component';
import { ManageUserComponent } from './admin/manage-user.component';
import { UserListComponent } from './admin/user-list.component';
import { ResetPassComponent } from './admin/reset-pass.component';
import { BroadcastComponent } from './admin/broadcast.component';
import { SendReceivestatsComponent } from './admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './admin/usernotusingmboard.component';
import { LastloginComponent } from './admin/lastlogin.component';
import { MsgReportComponent } from './admin/msg-report.component';
import { AdminProfileComponent } from './admin/admin-profile.component';


const routes: Routes = [
  //********************User Routes************************/
  { path: 'login', component: UserLoginComponent },
  { path: 'inbox', component: UserInboxComponent },
  { path: 'compose', component: UserComposeComponent },



  //********************Admin Login*************************/
  { path: 'admin', component: AdminLoginComponent },
  { path: 'dashboard', component: AdminDashboardComponent },
  { path: 'managegroup', component: ManageGroupComponent },
  { path: 'manageuser', component: ManageUserComponent },
  { path: 'userlist', component: UserListComponent },
  { path: 'resetPassword', component: ResetPassComponent },
  { path: 'broadcast', component: BroadcastComponent },
  { path: 'statistics', component: SendReceivestatsComponent },
  { path: 'usernoactivated', component: UsernotusingmboardComponent },
  { path: 'lastloginrpt', component: LastloginComponent },
  { path: 'messagerpt', component: MsgReportComponent },
  { path: 'adminprofile', component: AdminProfileComponent },


  //********************Default************************/
  { path: '', component: UserLoginComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
