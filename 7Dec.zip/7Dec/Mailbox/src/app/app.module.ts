import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserNavbarComponent } from './user/user-navbar.component';
import { UserSidebarComponent } from './user/user-sidebar.component';
import { UserInboxComponent } from './user/user-inbox.component';
import { UserFooterComponent } from './user/user-footer.component';
import { UserComposeComponent } from './user/user-compose.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { HttpClientModule } from '@angular/common/http';
import { UserLoginComponent } from './user/user-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { MailboxserviceService } from './mailboxservice.service';
import Swal from 'sweetalert2';
import { AdminDashboardComponent } from './admin/admin-dashboard.component';
import { ManageGroupComponent } from './admin/manage-group.component';
import { ManageUserComponent } from './admin/manage-user.component';
import { UserListComponent } from './admin/user-list.component';
import { ResetPassComponent } from './admin/reset-pass.component';
import { BroadcastComponent } from './admin/broadcast.component';
import { SendReceivestatsComponent } from './admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './admin/usernotusingmboard.component';
import { LastloginComponent } from './admin/lastlogin.component';
import { MsgReportComponent } from './admin/msg-report.component';
import { AdminProfileComponent } from './admin/admin-profile.component';
import { AdminSidebarComponent } from './admin/admin-sidebar.component';
import { AdminNavbarComponent } from './admin/admin-navbar.component';
import { AdminFooterComponent } from './admin/admin-footer.component';

@NgModule({
  declarations: [
    AppComponent,
    UserNavbarComponent,
    UserSidebarComponent,
    UserInboxComponent,
    UserFooterComponent,
    UserComposeComponent,
    UserLoginComponent,
    AdminLoginComponent,
    AdminDashboardComponent,
    ManageGroupComponent,
    ManageUserComponent,
    UserListComponent,
    ResetPassComponent,
    BroadcastComponent,
    SendReceivestatsComponent,
    UsernotusingmboardComponent,
    LastloginComponent,
    MsgReportComponent,
    AdminProfileComponent,
    AdminSidebarComponent,
    AdminNavbarComponent,
    AdminFooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSummernoteModule,
    HttpClientModule
  ],
  providers: [MailboxserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
