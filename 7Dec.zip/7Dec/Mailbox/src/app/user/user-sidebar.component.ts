import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-sidebar',
  templateUrl: './user-sidebar.component.html',
  styles: []
})
export class UserSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
