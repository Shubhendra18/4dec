import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-inbox',
  templateUrl: './user-inbox.component.html',
  styles: []
})
export class UserInboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
