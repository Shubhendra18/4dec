import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-user-inbox-info',
  templateUrl: './user-inbox-info.component.html',
  styles: []
})
export class UserInboxInfoComponent implements OnInit {
  Rid = localStorage.getItem("userToken");
  private maildetails: any = {};
  attachments: any = [];
  constructor(private service: MailboxserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      console.log(params.get('id'))
      var mailDes = { "mailId": params.get('id'), "rid": this.Rid };
      this.service.getmailDetails(mailDes).subscribe(k => {
        this.maildetails = k;
      })
      this.service.getattachments(mailDes).subscribe(k => {
        this.attachments = k;
      })
    });
  }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times']
  }
}
