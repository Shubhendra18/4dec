import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-pass',
  templateUrl: './reset-pass.component.html',
  styles: []
})
export class ResetPassComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
