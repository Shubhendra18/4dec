
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
declare var $;

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styles: []
})
export class UserlistComponent implements OnInit, OnDestroy {
  manageUserList: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  updateUserName: string = "";
  updateUserMobile: string = "";
  updateUserid: string = "";

  message = 'false';
  isActive: boolean = true;
  checkbox: boolean;
  public show: boolean = false;
  public buttonName: any = 'Show';

  constructor(private service: MailboxserviceService, private toaster: ToastrService) { }

  ngOnInit() {
    this.service.GetGroupUserForManage(0).subscribe(k => {
      this.manageUserList = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 8, pagingType: 'full_numbers'
    };
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  tosendUpdate(k) {
    this.updateUserName = k.officeName;
    this.updateUserMobile = k.mobileNo;
    this.updateUserid = k.userId;


  }
  ManageUserMaster(ManageUserData) {
    this.service.updateUserMaster(ManageUserData.value).subscribe(k => {
      if (k == 'Success') {
        this.toaster.success('Upated successfully!', 'Success');
        $("#userEdit").modal('hide');
        this.service.GetGroupUserForManage(0).subscribe(k => {
          this.manageUserList = k;
        });

      }
      else {
        this.toaster.error('Failed to Updated', 'Error');
      }
    });

  }

  checkValue(recflag) {
    if (recflag == "A") {
      console.log("A");
    }
    else {
      console.log("B");
    }
  }
  onChange(event, k) {
    k.checked = !k.checked;
    console.log(event, k);
  }

}
