import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styles: []
})
export class AdminSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
