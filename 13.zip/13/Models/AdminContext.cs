﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MandiParishadWebApi.Filters;
using MandiParishadWebApi.Models;
namespace MandiParishadWebApi.Models
{
    public class AdminContext : DbContext
    {
        public AdminContext() : base("MandiContext")
        {

        }
        public DbSet<M_GroupMaster> M_GroupMaster { get; set; }
        public AfterUserLogin UserLogin(string UserName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userName",Value=UserName},
                new SqlParameter {ParameterName="@LastLoginIP",Value=Common.GetIPAddress()},

                 };
            var sqlQuery = @"sp_newAdminLogin @userName,@LastLoginIP";
            var res = this.Database.SqlQuery<AfterUserLogin>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public GetUserProfileInfo LastLoginInfo(Int64 userId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                 };
            var sqlQuery = @"Sp_NewLastUserLoginInfo @userId";
            var res = this.Database.SqlQuery<GetUserProfileInfo>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public GetUserProfileInfo UpdateProfile(Int64 userId, string mobileNo, string Profilepic)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                new SqlParameter {ParameterName="@mobileNo",Value=mobileNo},
                new SqlParameter {ParameterName="@profilepic",Value=Profilepic},
                 };
            var sqlQuery = @"Sp_NewUpdateProfileInfo @userId,@mobileNo,@profilepic";
            var res = this.Database.SqlQuery<GetUserProfileInfo>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public object AddUpdateGroupName(int transId, String GroupName, int UserId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=transId},
                new SqlParameter {ParameterName="@groupName",Value=GroupName},
                new SqlParameter {ParameterName="@userId",Value=UserId},
                 };
            var sqlQuery = @"sp_saveUpdateGroup @transId,@groupName,@userId";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object DeleteGroup(int groupId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=groupId},
                 };
            var sqlQuery = @"sp_deleteGroup @transId";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object AddUser(AddUser addUser)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@NAME_OF_OFFICES",Value=addUser.officeName},
                new SqlParameter {ParameterName="@PASSWORD1",Value=addUser.password},
                new SqlParameter {ParameterName="@groupID",Value=addUser.groupID},
                new SqlParameter {ParameterName="@recflag",Value="A"},
                new SqlParameter {ParameterName="@mobileNo",Value=addUser.mobileNo},
                 };
            var sqlQuery = @"Proc_UserMaster_Ins @NAME_OF_OFFICES,@PASSWORD1,@groupID,@recflag,@mobileNo";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object GetUsersCount(int GroupId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=GroupId}
                 };
            var sqlQuery = @"Proc_selectUserCount @groupID";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object CheckUserName(String username)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userName",Value=username}
                 };
            var sqlQuery = @"Proc_getUserName @userName";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public List<UserByGroup> GetGroupUsers(int groupID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=groupID}
                 };
            var sqlQuery = @"Proc_selectUser @groupID";
            var res = this.Database.SqlQuery<UserByGroup>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string ComposeMail(int Priority, bool? SMS, string Subject, string Message, Int64 Sid, Int64 Rid, string msgid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@priority",Value=Priority},
                new SqlParameter {ParameterName="@sms",Value=SMS} ,
                new SqlParameter {ParameterName="@sub",Value=Subject} ,
                new SqlParameter {ParameterName="@msg",Value=Message},
                new SqlParameter {ParameterName="@sid",Value=Sid},
                new SqlParameter {ParameterName="@rid",Value=Rid},
                new SqlParameter {ParameterName="@messageid",Value=msgid}

                 };
            var sqlQuery = @"Sp_NewComposeMail @priority,@sms,@sub,@msg,@sid,@rid,@messageid";
            string res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserByGroup> GetGroupUsersforManage(int groupID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=groupID}
                 };
            var sqlQuery = @"Sp_NewselectUserByGroupForManage @groupID";
            var res = this.Database.SqlQuery<UserByGroup>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string updateUserMaster(UpdateuserModel model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=model.userId},
                new SqlParameter {ParameterName="@userName",Value=model.officeName},
                new SqlParameter {ParameterName="@mobileNo",Value=model.mobileNo},
                 };
            var sqlQuery = @"Sp_NewupdateUserMaster @userId,@userName,@mobileNo";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<LastLoginModel> GetlastloginReport()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=0}
                 };
            var sqlQuery = @"sp_NewgetLastLoginReport @groupID";
            var res = this.Database.SqlQuery<LastLoginModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public object CheckGroupName(String groupName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupName",Value=groupName}
                 };
            var sqlQuery = @"Sp_NewgetGroupName @groupName";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public List<SendAndReceiveModel> GetSendAndReceiveMsgs()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"sp_getSentAndReceivedStats @groupId";
            var res = this.Database.SqlQuery<SendAndReceiveModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetUsedUser()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"Sp_NewuserUsedUser @groupId";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetNotUsedUser()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"Sp_NewNotUsedUser @groupId";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetPostedMessageRecord(int postedid, int searchType, String searchCriteria, DateTime fromDate, DateTime toDate)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@postedid",Value=postedid},
                new SqlParameter {ParameterName="@searchType",Value=searchType},
                new SqlParameter {ParameterName="@searchCriteria",Value=searchCriteria},
                new SqlParameter {ParameterName="@fromDate",Value=fromDate},
                new SqlParameter {ParameterName="@toDate",Value=toDate},
                 };
            var sqlQuery = @"sp_getPostedMessageRecord @postedid,@searchType,@searchCriteria,@fromDate,@toDate";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }

        public string ActiveDeactiveUser(ActiveDeactive activeDeactive)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=activeDeactive.userId},
                new SqlParameter {ParameterName="@recflag",Value=activeDeactive.recflag}
                 };
            var sqlQuery = @"sp_NewActivateDeactivate @userId,@recflag";
            string res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
    }
}